package com.example.M13_SimpleHTTPService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M13SimpleHttpServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(M13SimpleHttpServiceApplication.class, args);
	}

}
