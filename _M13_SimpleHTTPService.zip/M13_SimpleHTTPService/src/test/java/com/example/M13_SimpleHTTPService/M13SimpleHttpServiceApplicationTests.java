package com.example.M13_SimpleHTTPService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M13SimpleHttpServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
